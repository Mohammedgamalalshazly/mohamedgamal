import 'package:flutter/material.dart';
import 'package:test1/quran.dart';
import 'Hmoves.dart';
import 'HomePage.dart';
import 'Hquran.dart';
import 'first.dart';
class anime extends StatefulWidget {
  @override
  State<anime> createState() => _HomeState();
}

class _HomeState extends State<anime> {
  bool isGridView = false;
  bool light = true;

  List<String> ImagesActionMoves = [
    "images/560.jpg","images/75.jpg","images/74.jpg","images/70.jpg","images/91.jpg",
    "images/363.jpg","images/79.jpg","images/70.jpg","images/78.jpg",
    "images/95.jpg","images/80.jpg","images/73.jpg","images/93.jpg",
    "images/94.jpg","images/81.jpg","images/72.jpg","images/80.jpg",
    "images/93.jpg","images/82.jpg","images/70.jpg","images/70.jpg",
    "images/92.jpg","images/83.jpg","images/71.jpg","images/72.jpg",
    "images/91.jpg","images/84.jpg","images/88.jpg",
    "images/90.jpg","images/85.jpg","images/89.jpg",
    "images/89.jpg","images/86.jpg","images/363.jpg",
    "images/88.jpg","images/76.jpg","images/94.jpg",
    "images/78.jpg","images/80.jpg",
  ];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        drawer: Drawer(
          backgroundColor: light ? Colors.blueGrey[50] : Colors.blueGrey[900],
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              height: double.infinity,
              width: double.infinity,
              child: ListView(
                  shrinkWrap: true,
                  children:[
                    Row(
                      children: [
                        IconButton(onPressed:(){
                          Navigator.of(context).pop();
                        }, icon:Icon(Icons.arrow_back_ios,color: light ? Colors.blue : Colors.orange, size: 25,)),
                      ],
                    ),
                    ListTile(
                      title: Icon(Icons.person, color: light ? Colors.blue : Colors.orange, size: 25,),
                      subtitle: Center(child: Text("Profile",style: TextStyle(fontSize: 15, color: light ? Colors.black : Colors.white ,))),
                      onTap: () {
                        Navigator.of(context).push(MaterialPageRoute(builder:(context){return First();}));

                      },
                    ),
                    ListTile(
                      title: Icon(Icons.home, color: light ? Colors.blue : Colors.orange, size: 25,),
                      subtitle: Center(child: Text("Soon", style: TextStyle(fontSize: 15, color: light ? Colors.black : Colors.white ,))),
                      onTap: () {
                        Navigator.of(context).push(MaterialPageRoute(builder:(context){return Profile();}));

                      },
                    ),
                    ListTile(
                      title: Icon(Icons.video_collection, color: light ? Colors.blue : Colors.orange, size: 25,),
                      subtitle: Center(child: Text("Anime movies", style: TextStyle(fontSize: 15, color: light ? Colors.black : Colors.white ,))),
                      onTap: () {
                        Navigator.of(context).push(MaterialPageRoute(builder:(context){return anime();}));

                      },
                    ),
                    ListTile(
                      title: Icon(Icons.video_collection, color: light ? Colors.blue : Colors.orange, size: 25,),
                      subtitle: Center(child: Text("Action movies", style: TextStyle(fontSize: 15, color: light ? Colors.black : Colors.white ,))),
                      onTap: () {
                        Navigator.of(context).push(MaterialPageRoute(builder:(context){return HomeMoves();}));

                      },
                    ),
                    ListTile(
                      title: Icon(Icons.video_collection, color: light ? Colors.blue : Colors.orange, size: 25,),
                      subtitle: Center(child: Text("TV Series", style: TextStyle(fontSize: 15, color: light ? Colors.black : Colors.white ,))),
                      onTap: () {},
                    ),
                    ListTile(
                      title: Icon(Icons.soup_kitchen_sharp, color: light ? Colors.blue : Colors.orange, size: 25,),
                      subtitle: Center(child: Text("َquran", style: TextStyle(fontSize: 15, color: light ? Colors.black : Colors.white ,))),
                      onTap: () {
                        Navigator.of(context).push(MaterialPageRoute(builder:(context){return Hquran();}));
                      },
                    ),
                  ]
              ),
            ),
          ),
        ),

        appBar: AppBar(
          centerTitle: true,
          title: Text(
            "Anime",
            style: TextStyle(
              color: light ? Colors.black : Colors.white,
              fontSize: 23,
            ),
          ),
          backgroundColor: light ? Colors.white : Colors.black,
          iconTheme: IconThemeData(
            color: light ? Colors.blueAccent : Colors.blueAccent,
          ),
          actions: [
            IconButton(
              icon: Icon(isGridView ? Icons.grid_4x4_rounded : Icons.table_rows),
              color: Colors.blueAccent,
              onPressed: () {
                setState(() {
                  isGridView = !isGridView;
                });
              },
            ),
            IconButton(
              icon: Icon(light ? Icons.light_mode : Icons.dark_mode),
              color: Colors.blueAccent,
              onPressed: () {
                setState(() {
                  light = !light;
                });
              },
            ),
          ],
        ),
        body: Container(
          height: double.infinity,
          width: double.infinity,
          color: light ? Colors.white : Colors.black,
          child: isGridView
              ? GridView.builder(
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3),
            scrollDirection: Axis.vertical,
            itemCount: ImagesActionMoves.length,
            itemBuilder: (context, i) {
              return GestureDetector(
                onLongPress: () {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return Dialog(
                        backgroundColor: Colors.transparent,
                        child: Image.asset(
                          ImagesActionMoves[i],
                          fit: BoxFit.cover,
                        ),
                      );
                    },
                  );
                },
                child: Image.asset(
                  ImagesActionMoves[i],
                  fit: BoxFit.cover,
                ),
              );
            },
          )
              : ListView.builder(
            scrollDirection: Axis.vertical,
            itemCount: ImagesActionMoves.length,
            itemBuilder: (context, i) {
              return GestureDetector(
                onLongPress: () {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return Dialog(
                        backgroundColor: Colors.transparent,
                        child: Image.asset(
                          ImagesActionMoves[i],
                          fit: BoxFit.cover,
                        ),
                      );
                    },
                  );
                },
                child: Image.asset(
                  ImagesActionMoves[i],
                  fit: BoxFit.cover,
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
