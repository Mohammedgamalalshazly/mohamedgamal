import 'package:flutter/material.dart';
import 'package:test1/quran.dart';
import 'Hmoves.dart';
import 'Anime.dart';
import 'Hquran.dart';
import 'first.dart';

class Profile extends StatefulWidget {
  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  bool isGridView = false;
  bool light = true;

  List<String> imagesActionMoves = [
    "images/58.jpg", "images/59.jpg", "images/61.jpg", "images/62.jpg", "images/63.jpg",
    "images/20.jpg", "images/21.jpg", "images/22.jpg", "images/23.jpg",
  ];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        drawer: Drawer(
          backgroundColor: light ? Colors.blueGrey[50] : Colors.blueGrey[900],
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              height: double.infinity,
              width: double.infinity,
              child: ListView(
                shrinkWrap: true,
                children: [
                  Row(
                    children: [
                      IconButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        icon: Icon(
                          Icons.arrow_back_ios,
                          color: light ? Colors.blue : Colors.orange,
                          size: 25,
                        ),
                      ),
                    ],
                  ),
                  ListTile(
                    title: Icon(
                      Icons.person,
                      color: light ? Colors.blue : Colors.orange,
                      size: 25,
                    ),
                    subtitle: Center(
                      child: Text(
                        "Profile",
                        style: TextStyle(
                          fontSize: 15,
                          color: light ? Colors.black : Colors.white,
                        ),
                      ),
                    ),
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => First()),
                      );
                    },
                  ),
                  ListTile(
                    title: Icon(
                      Icons.home,
                      color: light ? Colors.blue : Colors.orange,
                      size: 25,
                    ),
                    subtitle: Center(
                      child: Text(
                        "Soon",
                        style: TextStyle(
                          fontSize: 15,
                          color: light ? Colors.black : Colors.white,
                        ),
                      ),
                    ),
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => Profile()),
                      );
                    },
                  ),
                  ListTile(
                    title: Icon(
                      Icons.video_collection,
                      color: light ? Colors.blue : Colors.orange,
                      size: 25,
                    ),
                    subtitle: Center(
                      child: Text(
                        "Anime movies",
                        style: TextStyle(
                          fontSize: 15,
                          color: light ? Colors.black : Colors.white,
                        ),
                      ),
                    ),
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => anime()),
                      );
                    },
                  ),
                  ListTile(
                    title: Icon(
                      Icons.video_collection,
                      color: light ? Colors.blue : Colors.orange,
                      size: 25,
                    ),
                    subtitle: Center(
                      child: Text(
                        "Action movies",
                        style: TextStyle(
                          fontSize: 15,
                          color: light ? Colors.black : Colors.white,
                        ),
                      ),
                    ),
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => HomeMoves()),
                      );
                    },
                  ),
                  ListTile(
                    title: Icon(
                      Icons.video_collection,
                      color: light ? Colors.blue : Colors.orange,
                      size: 25,
                    ),
                    subtitle: Center(
                      child: Text(
                        "TV Series",
                        style: TextStyle(
                          fontSize: 15,
                          color: light ? Colors.black : Colors.white,
                        ),
                      ),
                    ),
                    onTap: () {
                      // أضف التنقل إذا كان مطلوباً
                    },
                  ),
                  ListTile(
                    title: Icon(
                      Icons.soup_kitchen_sharp,
                      color: light ? Colors.blue : Colors.orange,
                      size: 25,
                    ),
                    subtitle: Center(
                      child: Text(
                        "Quran",
                        style: TextStyle(
                          fontSize: 15,
                          color: light ? Colors.black : Colors.white,
                        ),
                      ),
                    ),
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => Hquran()),
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
        appBar: AppBar(
          centerTitle: true,
          title: Text(
            "Soon",
            style: TextStyle(
              color: light ? Colors.black : Colors.white,
              fontSize: 23,
            ),
          ),
          backgroundColor: light ? Colors.white : Colors.black,
          iconTheme: IconThemeData(
            color: light ? Colors.blueAccent : Colors.blueAccent,
          ),
          actions: [
            IconButton(
              icon: Icon(isGridView ? Icons.grid_4x4_rounded : Icons.table_rows),
              color: Colors.blueAccent,
              onPressed: () {
                setState(() {
                  isGridView = !isGridView;
                });
              },
            ),
            IconButton(
              icon: Icon(light ? Icons.light_mode : Icons.dark_mode),
              color: Colors.blueAccent,
              onPressed: () {
                setState(() {
                  light = !light;
                });
              },
            ),
          ],
        ),
        body: Container(
          height: double.infinity,
          width: double.infinity,
          color: light ? Colors.white : Colors.black,
          child: isGridView
              ? GridView.builder(
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 4,
              mainAxisSpacing: 4,
            ),
            itemCount: imagesActionMoves.length,
            itemBuilder: (context, i) {
              return GestureDetector(
                onLongPress: () {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return Dialog(
                        backgroundColor: Colors.transparent,
                        child: Image.asset(
                          imagesActionMoves[i],
                          fit: BoxFit.cover,
                        ),
                      );
                    },
                  );
                },
                child: Image.asset(
                  imagesActionMoves[i],
                  fit: BoxFit.cover,
                ),
              );
            },
          )
              : ListView.builder(
            scrollDirection: Axis.vertical,
            itemCount: imagesActionMoves.length,
            itemBuilder: (context, i) {
              return GestureDetector(
                onLongPress: () {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return Dialog(
                        backgroundColor: Colors.transparent,
                        child: Image.asset(
                          imagesActionMoves[i],
                          fit: BoxFit.cover,
                        ),
                      );
                    },
                  );
                },
                child: Image.asset(
                  imagesActionMoves[i],
                  fit: BoxFit.cover,
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
