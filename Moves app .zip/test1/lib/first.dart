import 'package:flutter/material.dart';
import 'Anime.dart';
import 'Hmoves.dart';
import 'HomePage.dart';
import 'Hquran.dart';

class First extends StatefulWidget {
  @override
  State<First> createState() => _FirstState();
}

class _FirstState extends State<First> {
  bool light = true;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        drawer: Drawer(
          backgroundColor: light ? Colors.blueGrey[50] : Colors.blueGrey[900],
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              height: double.infinity,
              width: double.infinity,
              child: ListView(
                shrinkWrap: true,
                children: [
                  Row(
                    children: [
                      IconButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        icon: Icon(
                          Icons.arrow_back_ios,
                          color: light ? Colors.blue : Colors.orange,
                          size: 25,
                        ),
                      ),
                    ],
                  ),
                  ListTile(
                    title: Icon(
                      Icons.person,
                      color: light ? Colors.blue : Colors.orange,
                      size: 25,
                    ),
                    subtitle: Center(
                      child: Text(
                        "Profile",
                        style: TextStyle(
                          fontSize: 15,
                          color: light ? Colors.black : Colors.white,
                        ),
                      ),
                    ),
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => First(),
                        ),
                      );
                    },
                  ),
                  ListTile(
                    title: Icon(
                      Icons.home,
                      color: light ? Colors.blue : Colors.orange,
                      size: 25,
                    ),
                    subtitle: Center(
                      child: Text(
                        "Soon",
                        style: TextStyle(
                          fontSize: 15,
                          color: light ? Colors.black : Colors.white,
                        ),
                      ),
                    ),
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => Profile(),
                        ),
                      );
                    },
                  ),
                  ListTile(
                    title: Icon(
                      Icons.video_collection,
                      color: light ? Colors.blue : Colors.orange,
                      size: 25,
                    ),
                    subtitle: Center(
                      child: Text(
                        "Anime movies",
                        style: TextStyle(
                          fontSize: 15,
                          color: light ? Colors.black : Colors.white,
                        ),
                      ),
                    ),
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => anime(),
                        ),
                      );
                    },
                  ),
                  ListTile(
                    title: Icon(
                      Icons.video_collection,
                      color: light ? Colors.blue : Colors.orange,
                      size: 25,
                    ),
                    subtitle: Center(
                      child: Text(
                        "Action movies",
                        style: TextStyle(
                          fontSize: 15,
                          color: light ? Colors.black : Colors.white,
                        ),
                      ),
                    ),
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => HomeMoves(),
                        ),
                      );
                    },
                  ),
                  ListTile(
                    title: Icon(
                      Icons.video_collection,
                      color: light ? Colors.blue : Colors.orange,
                      size: 25,
                    ),
                    subtitle: Center(
                      child: Text(
                        "TV Series",
                        style: TextStyle(
                          fontSize: 15,
                          color: light ? Colors.black : Colors.white,
                        ),
                      ),
                    ),
                    onTap: () {
                    },
                  ),
                  ListTile(
                    title: Icon(
                      Icons.soup_kitchen_sharp,
                      color: light ? Colors.blue : Colors.orange,
                      size: 25,
                    ),
                    subtitle: Center(
                      child: Text(
                        "Quran",
                        style: TextStyle(
                          fontSize: 15,
                          color: light ? Colors.black : Colors.white,
                        ),
                      ),
                    ),
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => Hquran(),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
        appBar: AppBar(
          centerTitle: true,
          title: Text(
            "Profile",
            style: TextStyle(
              color: light ? Colors.black : Colors.white,
              fontSize: 23,
            ),
          ),
          backgroundColor: light ? Colors.white : Colors.black,
          iconTheme: IconThemeData(
            color: light ? Colors.blueAccent : Colors.blueAccent,
          ),
          actions: [
            IconButton(
              icon: Icon(light ? Icons.light_mode : Icons.dark_mode),
              color: Colors.blueAccent,
              onPressed: () {
                setState(() {
                  light = !light;
                });
              },
            ),
          ],
        ),
        body: Container(
          height: double.infinity,
          width: double.infinity,
          color: light ? Colors.white : Colors.black,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              CircleAvatar(
                radius: 70,
                backgroundImage: NetworkImage('https://scontent.fcai20-5.fna.fbcdn.net/v/t39.30808-6/450246653_122213854736025320_4553903284359124361_n.jpg?_nc_cat=102&ccb=1-7&_nc_sid=6ee11a&_nc_ohc=9JMkq_XGedEQ7kNvgHOPU5E&_nc_ht=scontent.fcai20-5.fna&oh=00_AYA3kKArV-P0fcBMzQXoHVNvnAiwZQto3lL4NDkdpQninw&oe=66B5E578'),
                backgroundColor: Colors.grey[200],
              ),
              SizedBox(height: 20),

              Text(
                'Mohammed Rezk Elgarawany',
                style: TextStyle(
                color: light ? Colors.black : Colors.white,
                fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),

              Text(
                '01013384850',
                style: TextStyle(
                  fontSize: 18,
                  color: light ? Colors.black : Colors.white,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
