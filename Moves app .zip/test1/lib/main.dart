import "dart:async";

import"package:flutter/material.dart";

import "Anime.dart";
import "HomePage.dart";
import "first.dart";
void main(){
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
 home:Spage(),
));
}
class Spage extends StatefulWidget{
  @override
  State<Spage> createState() => _SpageState();
}

class _SpageState extends State<Spage> {
  void initState(){
    super.initState();
      Timer(
          Duration(seconds:2),(){
            Navigator.pushReplacement(context, MaterialPageRoute(builder:(context)=>First()));
      }
      );
  }
  Widget build (BuildContext context){
    return SafeArea(
      child: Scaffold(
          backgroundColor: Colors.white,
        body: Container(
          height: double.infinity,
          width: double.infinity,
          child:Image.asset("images/img.jpeg"),
        ),

      ),
    );
  }
}