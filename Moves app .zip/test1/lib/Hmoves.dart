import 'package:flutter/material.dart';
import 'package:test1/quran.dart';
import 'Anime.dart';
import 'HomePage.dart';
import 'Hquran.dart';
import 'first.dart';
class HomeMoves extends StatefulWidget {
  @override
  State<HomeMoves> createState() => _HomeState();
}

class _HomeState extends State<HomeMoves> {
  bool isGridView = false;
  bool light = true;

  List<String> ImagesActionMoves = [
    "images/1.jpg","images/2.jpg","images/3.jpg","images/4.jpg","images/5.jpg",
    "images/6.jpg","images/7.jpg","images/8.jpg","images/9.jpg",
    "images/10.jpg","images/11.jpg","images/12.jpg","images/13.jpg","images/14.jpg",
    "images/15.jpg","images/16.jpg","images/17.jpg","images/18.jpg",
    "images/20.jpg","images/21.jpg","images/22.jpg","images/23.jpg",
    "images/24.jpg","images/25.jpg","images/26.jpg","images/27.jpg",
    "images/6.jpg","images/7.jpg","images/8.jpg","images/9.jpg",
    "images/28.jpg","images/29.jpg","images/30.jpg","images/46.jpg","images/47.jpg",
    "images/48.jpg","images/49.jpg","images/50.jpg","images/51.jpg",
    "images/58.jpg","images/59.jpg","images/61.jpg","images/62.jpg","images/63.jpg",
    "images/20.jpg","images/21.jpg","images/22.jpg","images/23.jpg",
  ];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        drawer: Drawer(
          backgroundColor: light ? Colors.blueGrey[50] : Colors.blueGrey[900],
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              height: double.infinity,
              width: double.infinity,
              child: ListView(
                  shrinkWrap: true,
                  children:[
                    Row(
                      children: [
                        IconButton(onPressed:(){
                          Navigator.of(context).pop();
                        }, icon:Icon(Icons.arrow_back_ios,color: light ? Colors.blue : Colors.orange, size: 25,)),
                      ],
                    ),
                    ListTile(
                      title: Icon(Icons.person, color: light ? Colors.blue : Colors.orange, size: 25,),
                      subtitle: Center(child: Text("Profile",style: TextStyle(fontSize: 15, color: light ? Colors.black : Colors.white ,))),
                      onTap: () {
                        Navigator.of(context).push(MaterialPageRoute(builder:(context){return First();}));

                      },
                    ),
                    ListTile(
                      title: Icon(Icons.home, color: light ? Colors.blue : Colors.orange, size: 25,),
                      subtitle: Center(child: Text("Soon", style: TextStyle(fontSize: 15, color: light ? Colors.black : Colors.white ,))),
                      onTap: () {
                        Navigator.of(context).push(MaterialPageRoute(builder:(context){return Profile();}));

                      },
                    ),
                    ListTile(
                      title: Icon(Icons.video_collection, color: light ? Colors.blue : Colors.orange, size: 25,),
                      subtitle: Center(child: Text("Anime movies", style: TextStyle(fontSize: 15, color: light ? Colors.black : Colors.white ,))),
                      onTap: () {
                        Navigator.of(context).push(MaterialPageRoute(builder:(context){return anime();}));

                      },
                    ),
                    ListTile(
                      title: Icon(Icons.video_collection, color: light ? Colors.blue : Colors.orange, size: 25,),
                      subtitle: Center(child: Text("Action movies", style: TextStyle(fontSize: 15, color: light ? Colors.black : Colors.white ,))),
                      onTap: () {
                        Navigator.of(context).push(MaterialPageRoute(builder:(context){return HomeMoves();}));

                      },
                    ),
                    ListTile(
                      title: Icon(Icons.video_collection, color: light ? Colors.blue : Colors.orange, size: 25,),
                      subtitle: Center(child: Text("TV Series", style: TextStyle(fontSize: 15, color: light ? Colors.black : Colors.white ,))),
                      onTap: () {},
                    ),
                    ListTile(
                      title: Icon(Icons.soup_kitchen_sharp, color: light ? Colors.blue : Colors.orange, size: 25,),
                      subtitle: Center(child: Text("َquran", style: TextStyle(fontSize: 15, color: light ? Colors.black : Colors.white ,))),
                      onTap: () {
                        Navigator.of(context).push(MaterialPageRoute(builder:(context){return Hquran();}));
                      },
                    ),
                  ]
              ),
            ),
          ),
        ),

        appBar: AppBar(
          centerTitle: true,
          title: Text(
            "Action Moves",
            style: TextStyle(
              color: light ? Colors.black : Colors.white,
              fontSize: 23,
            ),
          ),
          backgroundColor: light ? Colors.white : Colors.black,
          iconTheme: IconThemeData(
            color: light ? Colors.blueAccent : Colors.blueAccent,
          ),
          actions: [
            IconButton(
              icon: Icon(isGridView ? Icons.grid_4x4_rounded : Icons.table_rows),
              color: Colors.blueAccent,
              onPressed: () {
                setState(() {
                  isGridView = !isGridView;
                });
              },
            ),
            IconButton(
              icon: Icon(light ? Icons.light_mode : Icons.dark_mode),
              color: Colors.blueAccent,
              onPressed: () {
                setState(() {
                  light = !light;
                });
              },
            ),
          ],
        ),
        body: Container(
          height: double.infinity,
          width: double.infinity,
          color: light ? Colors.white : Colors.black,
          child: isGridView
              ? GridView.builder(
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3),
            scrollDirection: Axis.vertical,
            itemCount: ImagesActionMoves.length,
            itemBuilder: (context, i) {
              return GestureDetector(
                onLongPress: () {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return Dialog(
                        backgroundColor: Colors.transparent,
                        child: Image.asset(
                          ImagesActionMoves[i],
                          fit: BoxFit.cover,
                        ),
                      );
                    },
                  );
                },
                child: Image.asset(
                  ImagesActionMoves[i],
                  fit: BoxFit.cover,
                ),
              );
            },
          )
              : ListView.builder(
            scrollDirection: Axis.vertical,
            itemCount: ImagesActionMoves.length,
            itemBuilder: (context, i) {
              return GestureDetector(
                onLongPress: () {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return Dialog(
                        backgroundColor: Colors.transparent,
                        child: Image.asset(
                          ImagesActionMoves[i],
                          fit: BoxFit.cover,
                        ),
                      );
                    },
                  );
                },
                child: Image.asset(
                  ImagesActionMoves[i],
                  fit: BoxFit.cover,
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
